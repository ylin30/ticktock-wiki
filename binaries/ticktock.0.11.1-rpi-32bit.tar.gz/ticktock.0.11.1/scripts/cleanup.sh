#!/bin/bash

rm -rf /tmp/tt/*
rm -rf /tmp/tt.bak/*

mkdir -p /tmp/tt/append
mkdir -p /tmp/tt/data
mkdir -p /tmp/tt/log

exit 0
