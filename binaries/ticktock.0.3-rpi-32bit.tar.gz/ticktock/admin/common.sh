#!/bin/bash

CURL='/usr/bin/curl -s'
HOST=127.0.0.1
PORT=6182
