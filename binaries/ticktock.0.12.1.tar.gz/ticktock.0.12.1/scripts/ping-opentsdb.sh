#!/bin/bash

curl http://localhost:4242/api/stats
echo

exit 0
